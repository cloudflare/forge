export { setObjectProperty } from "./setObjectProperty";
